#include <iostream>
#include <jni.h>
using namespace std;



void GenerateData()               //DO NOT TOUCH CODE IN THIS METHOD
{
     JavaVM *jvm;                      // Pointer to the JVM (Java Virtual Machine)
     JNIEnv *env;                      // Pointer to native interface
                                                              //================== prepare loading of Java VM ============================
     JavaVMInitArgs vm_args;                        // Initialization arguments
     JavaVMOption* options = new JavaVMOption[1];   // JVM invocation options
     options[0].optionString = (char*) "-Djava.class.path=";   // where to find java .class
     vm_args.version = JNI_VERSION_1_6;             // minimum Java version
     vm_args.nOptions = 1;                          // number of options
     vm_args.options = options;
     vm_args.ignoreUnrecognized = false;     // invalid options make the JVM init fail
                                                                          //=============== load and initialize Java VM and JNI interface =============
     jint rc = JNI_CreateJavaVM(&jvm, (void**)&env, &vm_args);  // YES !!
     delete options;    // we then no longer need the initialisation options.
     if (rc != JNI_OK) {
            // TO DO: error processing...
            cin.get();
            exit(EXIT_FAILURE);
     }
     //=============== Display JVM version =======================================
     cout << "JVM load succeeded: Version ";
     jint ver = env->GetVersion();
     cout << ((ver >> 16) & 0x0f) << "." << (ver & 0x0f) << endl;

     jclass cls2 = env->FindClass("ZooFileWriter");  // try to find the class
     if (cls2 == nullptr) {
            cerr << "ERROR: class not found !";
     }
     else {                                  // if class found, continue
            cout << "Class MyTest found" << endl;
            jmethodID mid = env->GetStaticMethodID(cls2, "createZooFile", "()V");  // find method
            if (mid == nullptr)
                   cerr << "ERROR: method void createZooFile() not found !" << endl;
            else {
                   env->CallStaticVoidMethod(cls2, mid);                      // call method
                   cout << endl;
            }
     }


     jvm->DestroyJavaVM();
     cin.get();
}

void AddAnimal(vector<Animal> animalVector)
{
	char check;
	char track[7];
	char name[16];
	char type[16];
	char subType[16];
	int eggs;
	int nurse;
	cout<<"Enter Track";
	cin>>track;
	cout<<"Enter name";
	cin>>name;
	cout<<"Ener type of animal : ";
	cin>>type;
	cout<<"Enter sub-type of animal : ";
	cin>>subType;
	cout<<"Enter number of eggs : ";
	cin>>eggs;
	cout<<"Enter nurse : ";
	cin>>nurse;
	
	cout<<"Do you want to save this data if yes enter y else n : "
	cin>>check;
	if(check=='y'|| check=='Y')
	{
		Animal animal= new Animal(track,name,type,subType,eggs,nurse);
		animalVector.push_back(animal);
		return;
	}
	else
	{
		AddAnimal();
		return;
	}
	
     
}


void RemoveAnimal(vector<Animal> vectorAnimal)
{
	char track[16];
	cout<<"Enter track to delete the animal : ";
	cin>>track;
	for(i=0;i<vectorAnimal.size();i++)
	{
		if(strcmp(vectorAnimal.track, track)==0)
		{
			vectorAnimal.remove(vectorAnimal[i]);
			return;
		}
	}
     
}

void DisplayAnimal(vector<Animal> vectorAnimal)
{
	for(int i=0;i<vectorAnimal.size();i++)
	{
		cout<< vectorAnimal[i].track<<" "<<vectorAnimal[i].name<<" "<<vectorAnimal[i].type<<" "<<vectorAnimal[i].subType<<" "<<vectorAnimal[i].eggs<<" "<<vectorAnimal[i].nurse<<endl;
	}
}

void LoadDataFromFile(vector<Animal> vectorAnimal)
{
	
	string filename="animal.txt";
	ifstream file;
	file.open(filename.c_str());
    if(file){
    	while(file!=EOF)
    	{
    		Animal animal;
    		file>>animal.track;
			file>>animal.name;
			file>>animal.type;
			file>>animal.subType;
			file>>animal.eggs;
			file>>animal.nurse;
			animalVector_push_back(animal);
		
    	}
    	return;
    }
    
}

void SaveDataToFile(vector<Animal> vectorAnimal)
{
	ofstream ofile;
	ofile.open("animal.txt");
	for(int i=0;i<vectorAnimal.size();i++)
	{
		ofile<<vectorAnimal[i].track<<" ";
		ofile<<vectorAnimal[i].name<<" ";
		ofile<<vectorAnimal[i].type<<" ";
		ofile<<vectorAnimal[i].subType<<" ";
		ofile<<vectorAnimal[i].eggs<<" ";
		ofile<<vectorAnimal[i].nurse<<"\n";
	}
	ofile.close();
     
}

void DisplayMenu()
{
	 cout<<"1. Load Animal Data"<<endl;
	 cout<<"2. Generate Data "<<endl;
	 cout<<"3. Display Data "<<endl;
     cout<<"4. Add Data"<<endl;
     cout<<"5. Delete Data"<<endl;
     cout<<"6. Save Data"<<endl;
  
}



int main()
{
	int choice;
	vector<Animal> animalVector;
	GenerateData();
	while(true)
	{
		DisplayMenu();
		cout<<" Enter your choice : ";
		cin>>choice;
		if(choice==1)
			LoadDataFromFile(animalVector);
		else if(choice==2)
			GenerateData();
		else if(choice==3)
			DisplayData(animalVector);
		else if (choice==4)
			AddAnimal(animalVector);
		else if(choice==5)
			RemoveAnimal(animalVector);
		else if(choice==6)
			SaveDataToFile(animalVector);
		else
			cout<<" Invalid Option !"<<endl;
			
	}
	return 1;
}
